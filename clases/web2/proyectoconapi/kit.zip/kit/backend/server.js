// 1. Cargar variables de entorno PRIMERO
require('dotenv').config();

const express = require('express');
const mysql = require('mysql2');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware para procesar datos JSON
app.use(express.json());

// Middleware CORS para permitir peticiones desde Apache (Puerto 80/8080)
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// 2. Conexión a MySQL usando las variables del archivo .env
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});

db.connect((err) => {
  if (err) {
    console.error('Error conectando a MySQL:', err.message);
  } else {
    console.log(`Conectado a la base de datos MySQL (${process.env.DB_NAME})`);
  }
});

// 3. Ruta POST para guardar usuarios
app.post('/api/usuarios', (req, res) => {
  const { txtnombre, txtemail, txtphone } = req.body;

  if (!txtnombre || !txtemail || !txtphone) {
    return res.status(400).json({
      exito: false,
      mensaje: 'Todos los campos son obligatorios.'
    });
  }

  const sql = 'INSERT INTO usuarios (nombre, email, telefono) VALUES (?, ?, ?)';
  
  db.query(sql, [txtnombre, txtemail, txtphone], (err, resultado) => {
    if (err) {
      console.error('Error al insertar:', err);
      return res.status(500).json({
        exito: false,
        mensaje: 'Error en la base de datos al guardar el usuario.'
      });
    }

    res.json({
      exito: true,
      mensaje: '¡Usuario guardado con éxito!',
      idInsertado: resultado.insertId
    });
  });
});

// Iniciar el servidor escuchando el puerto del .env
app.listen(PORT, () => {
  console.log(`Servidor API REST corriendo en http://localhost:${PORT}`);
});